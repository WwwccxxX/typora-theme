self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "50d2f4d972d97d317d703c75da17ee5c",
    "url": "./index.html"
  },
  {
    "revision": "668cb6bbf1541dd16b4c",
    "url": "./static/css/LicenseIndex.180dd4c7.eda2cf7b.chunk.css"
  },
  {
    "revision": "ba940ef68372039c1ebc",
    "url": "./static/css/Preferences.962926a4.fcba5383.chunk.css"
  },
  {
    "revision": "f4ab91c1cad5c335f919",
    "url": "./static/css/WelcomeIndex.63db304f.9f8ff12a.chunk.css"
  },
  {
    "revision": "102d4507111ee242c4b8",
    "url": "./static/css/localSettingIndex.a2c75cbd.4722268f.chunk.css"
  },
  {
    "revision": "bed0fa916a201e9e862f",
    "url": "./static/js/0.b6048905.chunk.js"
  },
  {
    "revision": "8b32dc95a2ee91e1b5d7d27e55fe304c",
    "url": "./static/js/0.b6048905.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0ca7bf3a0e5155a20bdf",
    "url": "./static/js/1.938c7957.chunk.js"
  },
  {
    "revision": "c7a4acbf94d097087228",
    "url": "./static/js/12.d508566d.chunk.js"
  },
  {
    "revision": "5735008847451525374b1f222e4ab316",
    "url": "./static/js/12.d508566d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "668cb6bbf1541dd16b4c",
    "url": "./static/js/LicenseIndex.180dd4c7.5dc16d09.chunk.js"
  },
  {
    "revision": "ba940ef68372039c1ebc",
    "url": "./static/js/Preferences.962926a4.2f63459f.chunk.js"
  },
  {
    "revision": "f4ab91c1cad5c335f919",
    "url": "./static/js/WelcomeIndex.63db304f.461f14e5.chunk.js"
  },
  {
    "revision": "102d4507111ee242c4b8",
    "url": "./static/js/localSettingIndex.a2c75cbd.fb18fd26.chunk.js"
  },
  {
    "revision": "ea0cdf525dc17ab2d173",
    "url": "./static/js/main.ff8bdafd.chunk.js"
  },
  {
    "revision": "32af8fee8c88440a3a0c",
    "url": "./static/js/runtime-LicenseIndex.180dd4c7.f7c007dd.js"
  },
  {
    "revision": "31eade27ad84fcd5e43c",
    "url": "./static/js/runtime-Preferences.962926a4.285eabb5.js"
  },
  {
    "revision": "68fdb37641c2c95f87f3",
    "url": "./static/js/runtime-WelcomeIndex.63db304f.ab2b23b4.js"
  },
  {
    "revision": "02c80b5dbf4b0857413b",
    "url": "./static/js/runtime-localSettingIndex.a2c75cbd.6f0fb930.js"
  },
  {
    "revision": "a58e29c10aa59053062a",
    "url": "./static/js/runtime-main.97d0b459.js"
  },
  {
    "revision": "06a6aa233c23b10f45b5ec4a8924866b",
    "url": "./static/media/icon.06a6aa23.png"
  },
  {
    "revision": "1382c29cdb72f6c99043675d6e13b625",
    "url": "./static/media/photon-entypo.1382c29c.ttf"
  },
  {
    "revision": "2614e058b2dcb9d6e2e964730d795540",
    "url": "./static/media/photon-entypo.2614e058.eot"
  },
  {
    "revision": "bf614256dbc49f4bf2cf786706bb0712",
    "url": "./static/media/photon-entypo.bf614256.woff"
  }
]);